package com.example.tunehub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectTuneHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
